package com.mycompany.meteoryty.model;
import com.mycompany.meteoryty.exception.InvalidMeteoriteDataException;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Repository class (Model component in MVC) that stores all {@link Meteorite} objects
 * in memory and provides methods for basic CRUD operations.
 *
 * <p>
 * The repository manages meteorite data using an {@link ArrayList} as an
 * in-memory database. Each meteorite is assigned a unique sequential ID.
 *
 * <p>
 * Supported operations include:
 * <ul>
 *   <li>adding a new meteorite (with validation),</li>
 *   <li>finding all or selected meteorites,</li>
 *   <li>searching by name or ID,</li>
 *   <li>updating and deleting entries,</li>
 *   <li>and computing statistics via helper classes (see {@code MeteoriteStats}).</li>
 * </ul>
 *
 * <p>
 * All domain validation rules (e.g. non-empty name, positive mass,
 * reasonable year range) are enforced in this class and violations
 * result in {@link InvalidMeteoriteDataException} being thrown.
 *
 * @author David Habryka
 * @version 2.0
 * @see Meteorite
 * @see InvalidMeteoriteDataException
 */
public class MeteoriteRepository {

    /** In-memory list storing all meteorite objects. */
    private final List<Meteorite> data = new ArrayList<>();

    /** Sequence counter used to assign unique IDs to new meteorites. */
    private int idSeq = 1;

    /**
     * Adds a new meteorite to the repository after validating input data.
     *
     * @param name meteorite name (non-blank)
     * @param massGrams mass in grams (must be positive)
     * @param year year of fall or discovery (valid range: 1400–2100)
     * @return the created {@link Meteorite} object
     * @throws InvalidMeteoriteDataException if provided data are invalid
     */
    public Meteorite add(String name, double massGrams, int year)
            throws InvalidMeteoriteDataException {
        validate(name, massGrams, year);
        Meteorite m = new Meteorite(idSeq++, name, massGrams, year);
        data.add(m);
        return m;
    }

    /**
     * Returns a copy of the list of all stored meteorites.
     *
     * <p>A new {@link ArrayList} is returned to preserve encapsulation — 
     * the original list cannot be modified from outside.
     *
     * @return list of all meteorites
     */
    public List<Meteorite> findAll() {
        return new ArrayList<>(data);
    }

    /**
     * Finds the heaviest meteorite in the repository.
     *
     * @return the meteorite with the greatest mass,
     *         or {@code null} if the repository is empty
     */
    public Meteorite findHeaviest() {
        return data.stream()
                .max(Comparator.comparingDouble(Meteorite::getMassGrams))
                .orElse(null);
    }

    /**
     * Searches meteorites by name (case-insensitive substring match).
     *
     * @param query text to look for within meteorite names
     * @return list of matching meteorites (empty list if none match or query is blank)
     */
    public List<Meteorite> findByName(String query) {
        if (query == null) return List.of();
        String q = query.trim().toLowerCase();
        if (q.isEmpty()) return List.of();

        return data.stream()
                .filter(m -> m.getName() != null && m.getName().toLowerCase().contains(q))
                .toList(); // requires Java 16+, otherwise: .collect(Collectors.toList())
    }

    /**
     * Finds a meteorite by its unique ID.
     *
     * @param id the meteorite identifier
     * @return the corresponding {@link Meteorite}, or {@code null} if not found
     */
    public Meteorite findById(int id) {
        for (Meteorite m : data) {
            if (m.getId() == id) return m;
        }
        return null;
    }

    /**
     * Updates an existing meteorite record (in place).
     *
     * @param id meteorite ID to update
     * @param newName new meteorite name (non-blank)
     * @param newMassGrams new mass in grams (must be positive)
     * @param newYear new year of fall/discovery (range: 1400–2100)
     * @return updated {@link Meteorite} object, or {@code null} if no meteorite with given ID exists
     * @throws InvalidMeteoriteDataException if provided data fail validation
     */
    public Meteorite update(int id, String newName, double newMassGrams, int newYear)
            throws InvalidMeteoriteDataException {
        Meteorite m = findById(id);
        if (m == null) return null;
        validate(newName, newMassGrams, newYear);

        m.setName(newName);
        m.setMassGrams(newMassGrams);
        m.setYear(newYear);
        return m;
    }

    /**
     * Deletes a meteorite from the repository by its ID.
     *
     * @param id the meteorite ID to remove
     * @return {@code true} if the meteorite was found and removed,
     *         {@code false} if the ID does not exist
     */
    public boolean deleteById(int id) {
        return data.removeIf(m -> m.getId() == id);
    }

    /**
     * Returns the number of meteorites stored in the repository.
     *
     * @return count of stored meteorite objects
     */
    public int count() {
        return data.size();
    }

    /**
     * Validates meteorite data according to domain rules.
     *
     * @param name meteorite name (must not be blank)
     * @param massGrams mass (must be positive)
     * @param year year (must be within 1400–2100)
     * @throws InvalidMeteoriteDataException if any argument violates domain rules
     */
    private void validate(String name, double massGrams, int year)
            throws InvalidMeteoriteDataException {
        if (name == null || name.isBlank()) {
            throw new InvalidMeteoriteDataException("Meteorite name cannot be empty.");
        }
        if (massGrams <= 0) {
            throw new InvalidMeteoriteDataException("Meteorite mass must be positive.");
        }
        if (year < 1400 || year > 2100) {
            throw new InvalidMeteoriteDataException("Meteorite year must be between 1400 and 2100.");
        }
    }
}
