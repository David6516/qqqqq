package com.mycompany.meteoryty.view;

import com.mycompany.meteoryty.controller.GuiController;
import com.mycompany.meteoryty.exception.InvalidMeteoriteDataException;
import com.mycompany.meteoryty.model.Meteorite;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Main GUI window of the application.
 * <p>
 * Provides the user interface to view, add, edit, delete, search, sort,
 * and display statistics for meteorite records.
 */
public class GuiView extends JFrame {

    /** Controller mediating between the GUI and the data repository. */
    private final GuiController controller;

    /** Table model that stores meteorite rows. */
    private final MeteoriteTableModel tableModel = new MeteoriteTableModel();
    /** Swing JTable bound to {@link #tableModel}. */
    private final JTable table = new JTable(tableModel);
    /** Status bar shown at the bottom of the window. */
    private final JLabel status = new JLabel("Ready");
    /** Search text field (by name). */
    private final JTextField tfSearch = new JTextField(16);

    // --- sort UI ---
    private final JComboBox<String> cbSortKey =
            new JComboBox<>(new String[]{"Name", "Mass", "Year"});
    private final JComboBox<String> cbSortOrder =
            new JComboBox<>(new String[]{"Ascending", "Descending"});

    /**
     * Constructs and initializes the main window.
     *
     * @param controller controller used to access meteorite data
     */
    public GuiView(GuiController controller) {
        super("Meteorite Database — GUI (Minimal)");
        this.controller = controller;

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8)); // 8px gaps

        // MENU & ACTIONS (keep it minimal and consistent)
        var actions = createActions();
        setJMenuBar(buildMenuBar(actions));

        // TOOLBAR + SEARCH + SORT area
        var north = new JPanel(new BorderLayout());
        north.add(buildToolBar(actions), BorderLayout.NORTH);
        north.add(buildSearchPanel(actions), BorderLayout.CENTER);
        north.add(buildSortPanel(actions), BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);

        // Global Alt+F4 binding (works even if OS steals the shortcut)
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke("alt F4"), "app-exit");
        getRootPane().getActionMap()
                .put("app-exit", new AbstractAction() {
                    @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                        // Reuse the same Exit action
                        actions.exit.actionPerformed(e);
                    }
                });

        // Table (list)
        table.setFillsViewportHeight(true);
        table.getAccessibleContext().setAccessibleName("Meteorites table");
        table.getAccessibleContext().setAccessibleDescription("Table listing meteorites (id, name, mass, year)");
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Status bar
        status.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        add(status, BorderLayout.SOUTH);

        // Initial load
        reloadAll();

        setMinimumSize(new Dimension(720, 460));
        setLocationRelativeTo(null);
    }

    /** Shows the window. */
    public void showWindow() { setVisible(true); }

    // === Actions ===

    /** Small bundle to keep all Swing Actions together. */
    private static final class ActionMapBundle {
        Action add, edit, delete, heaviest, searchFocus, searchRun, reset, stats, sort, exit;
    }

    /**
     * Creates and wires all actions (menu, toolbar, accelerators).
     */
    private ActionMapBundle createActions() {
        var a = new ActionMapBundle();

        // Add
        a.add = new AbstractAction("Add") {
            { putValue(SHORT_DESCRIPTION, "Add new meteorite");
              putValue(MNEMONIC_KEY, KeyEvent.VK_A);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onAdd(); }
        };

        // Edit
        a.edit = new AbstractAction("Edit") {
            { putValue(SHORT_DESCRIPTION, "Edit selected meteorite");
              putValue(MNEMONIC_KEY, KeyEvent.VK_E);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onEditSelected(); }
        };

        // Delete
        a.delete = new AbstractAction("Delete") {
            { putValue(SHORT_DESCRIPTION, "Delete selected meteorite");
              putValue(MNEMONIC_KEY, KeyEvent.VK_D);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("DELETE")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onDeleteSelected(); }
        };

        // Heaviest
        a.heaviest = new AbstractAction("Heaviest") {
            { putValue(SHORT_DESCRIPTION, "Show and select heaviest meteorite");
              putValue(MNEMONIC_KEY, KeyEvent.VK_H); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onHeaviest(); }
        };

        // Focus search
        a.searchFocus = new AbstractAction("Search by name") {
            { putValue(SHORT_DESCRIPTION, "Focus search field");
              putValue(MNEMONIC_KEY, KeyEvent.VK_S);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control F")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onSearchFocus(); }
        };

        // Run search
        a.searchRun = new AbstractAction("Find") {
            { putValue(SHORT_DESCRIPTION, "Run search by name");
              putValue(MNEMONIC_KEY, KeyEvent.VK_F); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onSearchNow(); }
        };

        // Reset search
        a.reset = new AbstractAction("Reset") {
            { putValue(SHORT_DESCRIPTION, "Clear search and show all");
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control R"));
              putValue(MNEMONIC_KEY, KeyEvent.VK_R); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onResetSearch(); }
        };

        // Stats
        a.stats = new AbstractAction("Stats") {
            { putValue(SHORT_DESCRIPTION, "Show count, total mass and average mass");
              putValue(MNEMONIC_KEY, KeyEvent.VK_T);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control T")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onStats(); }
        };

        // Sort
        a.sort = new AbstractAction("Sort") {
            { putValue(SHORT_DESCRIPTION, "Sort current list by selected key and order");
              putValue(MNEMONIC_KEY, KeyEvent.VK_O); // O like Order
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control shift S")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onSortNow(); }
        };

        // Exit
        a.exit = new AbstractAction("Exit") {
            {
                putValue(SHORT_DESCRIPTION, "Close the application");
                putValue(MNEMONIC_KEY, KeyEvent.VK_X);
                // Ctrl+Q on Win/Linux, ⌘Q on macOS
                putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(
                        KeyEvent.VK_Q,
                        Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()
                ));
            }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                System.exit(0);
            }
        };

        return a;
    }

    /**
     * Builds the top menu bar.
     */
    private JMenuBar buildMenuBar(ActionMapBundle a) {
        var bar = new JMenuBar();
        var m = new JMenu("Actions");
        m.setMnemonic(KeyEvent.VK_C); // Alt+C
        m.add(new JMenuItem(a.add));
        m.add(new JMenuItem(a.edit));
        m.add(new JMenuItem(a.delete));
        m.add(new JMenuItem(a.heaviest));
        m.addSeparator();
        m.add(new JMenuItem(a.searchFocus));
        m.add(new JMenuItem(a.searchRun));
        m.add(new JMenuItem(a.reset));
        m.add(new JMenuItem(a.stats));
        m.add(new JMenuItem(a.sort));
        m.addSeparator();
        m.add(new JMenuItem(a.exit));
        bar.add(m);
        return bar;
    }

    /**
     * Builds the main toolbar with action buttons.
     */
    private JToolBar buildToolBar(ActionMapBundle a) {
        var tb = new JToolBar();
        tb.setFloatable(false);

        var bAdd = tb.add(a.add);
        var bEdit = tb.add(a.edit);
        var bDelete = tb.add(a.delete);

        var bHeaviest = tb.add(a.heaviest);
        var bStats = tb.add(a.stats);
        bStats.setToolTipText("Stats (Ctrl+T)");
        bStats.getAccessibleContext().setAccessibleName("Stats");
        bStats.getAccessibleContext().setAccessibleDescription("Show total and average mass statistics");
        tb.addSeparator();
        var bExit = tb.add(a.exit);
        bExit.setToolTipText("Exit (Ctrl+Q / Alt+X)");
        bAdd.setToolTipText("Add new meteorite (Ctrl+N)");
        bHeaviest.setToolTipText("Show heaviest meteorite");
        bEdit.setToolTipText("Edit selected (Ctrl+E)");
        bDelete.setToolTipText("Delete selected (Del)");

        tb.getAccessibleContext().setAccessibleName("Main toolbar");
        tb.getAccessibleContext().setAccessibleDescription("Toolbar with core actions (add, edit, delete, heaviest, stats, exit)");
        return tb;
    }

    /**
     * Builds the search panel (search by name).
     */
    private JComponent buildSearchPanel(ActionMapBundle a) {
        var p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));

        var l = new JLabel("Search:");
        l.setDisplayedMnemonic(KeyEvent.VK_S);
        l.setLabelFor(tfSearch);

        tfSearch.setToolTipText("Type a fragment of name (case-insensitive)");
        tfSearch.getAccessibleContext().setAccessibleName("Search field");
        tfSearch.getAccessibleContext().setAccessibleDescription("Enter meteorite name fragment to search");

        // Pressing Enter triggers the search
        tfSearch.addActionListener(e -> onSearchNow());

        var bFind = new JButton(a.searchRun);
        bFind.setToolTipText("Find (Enter)");
        bFind.getAccessibleContext().setAccessibleName("Find button");
        bFind.getAccessibleContext().setAccessibleDescription("Run search by name");

        var bReset = new JButton(a.reset);
        bReset.setToolTipText("Reset search (show all)");
        bReset.getAccessibleContext().setAccessibleName("Reset button");
        bReset.getAccessibleContext().setAccessibleDescription("Clear search and show all records");

        p.add(l);
        p.add(tfSearch);
        p.add(bFind);
        p.add(bReset);

        p.getAccessibleContext().setAccessibleName("Search panel");
        p.getAccessibleContext().setAccessibleDescription("Search by name tools");
        return p;
    }

    /**
     * Builds the sort panel (key + order + button).
     */
    private JComponent buildSortPanel(ActionMapBundle a) {
        var p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));

        var lKey = new JLabel("Sort by:");
        lKey.setDisplayedMnemonic(KeyEvent.VK_B); // Alt+B (By)
        lKey.setLabelFor(cbSortKey);

        cbSortKey.setToolTipText("Sort key");
        cbSortKey.getAccessibleContext().setAccessibleName("Sort key");
        cbSortKey.getAccessibleContext().setAccessibleDescription("Choose field to sort by");

        var lOrder = new JLabel("Order:");
        lOrder.setDisplayedMnemonic(KeyEvent.VK_O);
        lOrder.setLabelFor(cbSortOrder);

        cbSortOrder.setToolTipText("Sort order");
        cbSortOrder.getAccessibleContext().setAccessibleName("Sort order");
        cbSortOrder.getAccessibleContext().setAccessibleDescription("Choose ascending or descending");

        var bSort = new JButton(a.sort);
        bSort.setToolTipText("Sort (Ctrl+Shift+S)");
        bSort.getAccessibleContext().setAccessibleName("Sort button");
        bSort.getAccessibleContext().setAccessibleDescription("Sort the current table");

        p.add(lKey);
        p.add(cbSortKey);
        p.add(lOrder);
        p.add(cbSortOrder);
        p.add(bSort);

        p.getAccessibleContext().setAccessibleName("Sort panel");
        p.getAccessibleContext().setAccessibleDescription("Controls for sorting the table");
        return p;
    }

    // ========== Handlers ==========

    /** Reloads all data and updates the status bar. */
    private void reloadAll() {
        tableModel.setRows(controller.getAll());
        status.setText("Items: " + tableModel.getRowCount());
    }

    /** Handler for Add action. Opens a modal form and adds a record on confirm. */
    private void onAdd() {
        var form = new MeteoriteForm(this, "Add meteorite");
        var data = form.showDialog();
        if (data == null) return;
        try {
            controller.add(data.name, data.mass, data.year);
            reloadAll();
            status.setText("Added: " + data.name);
        } catch (InvalidMeteoriteDataException ex) {
            // Minimal message per requirements
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid data", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Handler for Heaviest action. Selects and shows the heaviest record (if any). */
    private void onHeaviest() {
        var m = controller.findHeaviest();
        if (m == null) {
            JOptionPane.showMessageDialog(this, "No data.", "Heaviest", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int idx = tableModel.indexOfId(m.getId());
        if (idx >= 0) {
            table.getSelectionModel().setSelectionInterval(idx, idx);
            table.scrollRectToVisible(table.getCellRect(idx, 0, true));
        }
        JOptionPane.showMessageDialog(this, "Heaviest: " + m, "Heaviest", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Handler for Edit action. Opens a prefilled form for the selected row and updates it on confirm. */
    private void onEditSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a row to edit.", "Edit", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        var m = tableModel.getAt(row);

        // Prefilled form (uses the second constructor)
        MeteoriteForm form = new MeteoriteForm(this, "Edit meteorite", m.getName(), m.getMassGrams(), m.getYear());
        var data = form.showDialog();
        if (data == null) return;

        try {
            controller.update(m.getId(), data.name, data.mass, data.year);
            reloadAll();
            // Try to reselect the updated row
            int idx = tableModel.indexOfId(m.getId());
            if (idx >= 0) {
                table.getSelectionModel().setSelectionInterval(idx, idx);
                table.scrollRectToVisible(table.getCellRect(idx, 0, true));
            }
            status.setText("Updated: #" + m.getId());
        } catch (InvalidMeteoriteDataException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid data", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Handler for Delete action. Confirms and deletes the selected record. */
    private void onDeleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a row to delete.", "Delete", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        var m = tableModel.getAt(row);
        int res = JOptionPane.showConfirmDialog(this, "Delete: " + m + " ?", "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION) return;

        if (controller.delete(m.getId())) {
            reloadAll();
            status.setText("Deleted: #" + m.getId());
        } else {
            JOptionPane.showMessageDialog(this, "Delete failed (id not found).", "Delete", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Handler that focuses the search field and selects its text. */
    private void onSearchFocus() {
        tfSearch.requestFocusInWindow();
        tfSearch.selectAll();
        status.setText("Type name and press Enter or 'Find'.");
    }

    /** Handler that executes the current search or resets to all items when empty. */
    private void onSearchNow() {
        String q = tfSearch.getText().trim();
        if (q.isEmpty()) {
            reloadAll();
            status.setText("Search cleared. Showing all.");
            return;
        }
        var results = controller.findByName(q);
        tableModel.setRows(results);
        status.setText("Found: " + results.size());
    }

    /** Clears the search field and reloads all items. */
    private void onResetSearch() {
        tfSearch.setText("");
        reloadAll();
        status.setText("Reset search.");
    }

    /** Shows simple statistics (count, total mass, average mass). */
    private void onStats() {
        var s = controller.stats();
        if (s.count == 0) {
            JOptionPane.showMessageDialog(this, "No data.", "Stats", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String msg = String.format(
                "Count: %d%nTotal mass: %.0f g%nAverage mass: %.2f g",
                s.count, s.totalMass, s.averageMass
        );
        JOptionPane.showMessageDialog(this, msg, "Stats", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Sorts current table rows using the selected key and order. */
    private void onSortNow() {
        String key = String.valueOf(cbSortKey.getSelectedItem());
        String order = String.valueOf(cbSortOrder.getSelectedItem());

        // Take what is currently displayed (e.g., after a search), sort, and display again
        List<Meteorite> list = tableModel.getRowsCopy();

        java.util.Comparator<Meteorite> cmp;
        switch (key) {
            case "Name" -> cmp = java.util.Comparator.comparing(
                    Meteorite::getName,
                    java.util.Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
            );
            case "Mass" -> cmp = java.util.Comparator.comparingDouble(Meteorite::getMassGrams);
            case "Year" -> cmp = java.util.Comparator.comparingInt(Meteorite::getYear);
            default -> cmp = java.util.Comparator.comparing(
                    Meteorite::getName,
                    java.util.Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
            );
        }
        if ("Descending".equalsIgnoreCase(order)) {
            cmp = cmp.reversed();
        }

        list.sort(cmp);
        tableModel.setRows(list);

        status.setText("Sorted by " + key + " (" + order.toLowerCase() + ")");
    }

    // ========== Table model ==========

    /**
     * Minimal table model for meteorites displayed in the GUI table.
     */
    private static final class MeteoriteTableModel extends AbstractTableModel {
        private final String[] cols = {"ID", "Name", "Mass [g]", "Year"};
        private List<Meteorite> rows = new ArrayList<>();

        /** Replaces current rows and refreshes the table. */
        public void setRows(List<Meteorite> newRows) {
            this.rows = new ArrayList<>(newRows);
            fireTableDataChanged();
        }

        /** Returns a shallow copy of current rows (safe for sorting outside). */
        public java.util.List<Meteorite> getRowsCopy() {
            return new java.util.ArrayList<>(rows);
        }

        /** Finds the row index by meteorite id, or -1 if not found. */
        public int indexOfId(int id) {
            for (int i = 0; i < rows.size(); i++) if (rows.get(i).getId() == id) return i;
            return -1;
        }

        /** Returns meteorite at row index (used for editing). */
        public Meteorite getAt(int row) { return rows.get(row); }

        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int column) { return cols[column]; }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            var m = rows.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> m.getId();
                case 1 -> m.getName();
                case 2 -> m.getMassGrams();
                case 3 -> m.getYear();
                default -> null;
            };
        }

        @Override public Class<?> getColumnClass(int columnIndex) {
            return switch (columnIndex) {
                case 0, 3 -> Integer.class;
                case 2 -> Double.class;
                default -> String.class;
            };
        }
    }

    // ========== Minimal form dialog ==========

    /**
     * Minimal modal dialog used for adding/editing a single meteorite.
     */
    private static final class MeteoriteForm extends JDialog {

        /** Simple immutable container for collected form data. */
        static final class Data {
            final String name; final double mass; final int year;
            Data(String name, double mass, int year) { this.name = name; this.mass = mass; this.year = year; }
        }

        /** Result set when OK is pressed; {@code null} if canceled. */
        private Data result;

        private final JTextField tfName = new JTextField(20);
        private final JTextField tfMass = new JTextField(10);
        private final JTextField tfYear = new JTextField(8);

        /**
         * Creates the dialog and builds the UI.
         */
        MeteoriteForm(Window owner, String title) {
            super(owner, title, ModalityType.APPLICATION_MODAL);
            setLayout(new BorderLayout(8, 8));

            var panel = new JPanel(new GridBagLayout());
            var c = new GridBagConstraints();
            c.insets = new Insets(4, 8, 4, 8);
            c.anchor = GridBagConstraints.WEST;
            c.gridy = 0;

            var lName = new JLabel("Name:");
            lName.setDisplayedMnemonic(KeyEvent.VK_N);
            lName.setLabelFor(tfName);
            tfName.setToolTipText("Meteorite name");
            tfName.getAccessibleContext().setAccessibleName("Name field");
            tfName.getAccessibleContext().setAccessibleDescription("Enter meteorite name");

            var lMass = new JLabel("Mass [g]:");
            lMass.setDisplayedMnemonic(KeyEvent.VK_M);
            lMass.setLabelFor(tfMass);
            tfMass.setToolTipText("Mass in grams");
            tfMass.getAccessibleContext().setAccessibleName("Mass field");

            var lYear = new JLabel("Year:");
            lYear.setDisplayedMnemonic(KeyEvent.VK_Y);
            lYear.setLabelFor(tfYear);
            tfYear.setToolTipText("Year of fall/discovery");
            tfYear.getAccessibleContext().setAccessibleName("Year field");

            c.gridx = 0; panel.add(lName, c);
            c.gridx = 1; panel.add(tfName, c);
            c.gridy++; c.gridx = 0; panel.add(lMass, c);
            c.gridx = 1; panel.add(tfMass, c);
            c.gridy++; c.gridx = 0; panel.add(lYear, c);
            c.gridx = 1; panel.add(tfYear, c);

            add(panel, BorderLayout.CENTER);

            var btnOk = new JButton("OK");
            btnOk.setMnemonic(KeyEvent.VK_O);
            btnOk.setToolTipText("Confirm values");
            btnOk.addActionListener(e -> {
                try {
                    String n = tfName.getText().trim();
                    double m = Double.parseDouble(tfMass.getText().trim().replace(',', '.'));
                    int y = Integer.parseInt(tfYear.getText().trim());
                    result = new Data(n, m, y);
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Enter valid numbers for mass and year.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                }
            });

            var btnCancel = new JButton("Cancel");
            btnCancel.setMnemonic(KeyEvent.VK_C);
            btnCancel.addActionListener(e -> { result = null; dispose(); });

            var buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttons.add(btnCancel);
            buttons.add(btnOk);
            add(buttons, BorderLayout.SOUTH);

            getRootPane().setDefaultButton(btnOk);
            pack();
            setLocationRelativeTo(owner);
        }

        /**
         * Prefilled constructor used for editing an existing record.
         */
        MeteoriteForm(Window owner, String title, String name, double mass, int year) {
            this(owner, title); // build base UI first
            tfName.setText(name);
            tfMass.setText(Double.toString(mass));
            tfYear.setText(Integer.toString(year));
        }

        /**
         * Shows the dialog modally and returns the user input, or {@code null} if canceled.
         */
        Data showDialog() { setVisible(true); return result; }
    }
}
