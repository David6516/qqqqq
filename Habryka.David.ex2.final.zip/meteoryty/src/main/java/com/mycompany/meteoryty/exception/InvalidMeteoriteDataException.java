package com.mycompany.meteoryty.exception;

/**
 * Exception thrown when invalid meteorite data is provided to the Model layer.
 *
 * <p>
 * This exception is used to signal domain-level validation errors within
 * {@link com.mycompany.meteoryty.model.MeteoriteRepository} — for example:
 * <ul>
 *   <li>negative or zero mass values,</li>
 *   <li>unrealistic discovery year,</li>
 *   <li>or any other data inconsistency defined by domain rules.</li>
 * </ul>
 *
 * <p>
 * The controller layer ({@code AppController}) is responsible for catching
 * this exception and displaying an appropriate message to the user.
 *
 * @author David Habryka
 * @version 2.0
 */
public class InvalidMeteoriteDataException extends Exception {

    /**
     * Constructs a new {@code InvalidMeteoriteDataException} with a detail message
     * describing the reason of invalid data.
     *
     * @param message human-readable description of what data was invalid
     */
    public InvalidMeteoriteDataException(String message) {
        super(message);
    }
}
