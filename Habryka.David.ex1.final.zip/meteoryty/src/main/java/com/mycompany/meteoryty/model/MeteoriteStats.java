package com.mycompany.meteoryty.model;

import java.util.List;

/**
 * Utility class that performs statistical calculations on collections of {@link Meteorite} objects.
 *
 * <p>
 * This class provides simple aggregate functions that operate on a list of meteorites:
 * <ul>
 *   <li>computing the total mass of all meteorites,</li>
 *   <li>and computing the average mass of meteorites in the collection.</li>
 * </ul>
 *
 * <p>
 * It contains only static-like behavior (no instance fields) and does not modify
 * the provided data — it is purely functional.
 *
 * @author David Habryka
 * @version 2.0
 * @see Meteorite
 */
public class MeteoriteStats {

    /**
     * Calculates the total mass of all meteorites in the given list.
     *
     * @param list a list of {@link Meteorite} objects (may be empty)
     * @return total mass of all meteorites in grams;
     *         returns {@code 0.0} if the list is empty
     */
    public double totalMass(List<Meteorite> list) {
        return list.stream()
                .mapToDouble(Meteorite::getMassGrams)
                .sum();
    }

    /**
     * Calculates the average mass of meteorites in the given list.
     *
     * @param list a list of {@link Meteorite} objects (may be empty)
     * @return average mass in grams; {@code 0.0} if the list is empty
     */
    public double averageMass(List<Meteorite> list) {
        int n = list.size();
        if (n == 0) return 0.0;
        return totalMass(list) / n;
    }
}
