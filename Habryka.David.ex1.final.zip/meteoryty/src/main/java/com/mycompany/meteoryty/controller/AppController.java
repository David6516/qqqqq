package com.mycompany.meteoryty.controller;

import com.mycompany.meteoryty.model.MeteoriteRepository;
import com.mycompany.meteoryty.view.ConsoleView;
import com.mycompany.meteoryty.model.Meteorite;
import java.util.List;
import java.util.Comparator;

/**
 * Application controller (MVC) that connects the {@code ConsoleView} with the
 * {@code MeteoriteRepository} and orchestrates all user flows.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>show the main menu and dispatch user choices,</li>
 *   <li>read user input via {@link ConsoleView},</li>
 *   <li>call model operations in {@link MeteoriteRepository},</li>
 *   <li>handle domain errors thrown by the model and present messages to the user.</li>
 * </ul>
 * This class contains no persistence or business calculations itself; it only
 * coordinates View &amp; Model.
 *
 * @author David Habryka
 * @version 2.0
 */
public class AppController {

    /** Repository (Model) that stores and queries meteorite data. */
    private final MeteoriteRepository repo;

    /** Console-based user interface for input/output. */
    private final ConsoleView view;

    /**
     * Creates the controller with injected dependencies (Model and View).
     *
     * @param repo repository used to manage meteorites
     * @param view console view used for I/O
     */
    public AppController(MeteoriteRepository repo, ConsoleView view) {
        this.repo = repo;
        this.view = view;
    }

    /**
     * Runs the main interactive loop.
     * <p>
     * Shows the menu, reads the user's choice and dispatches to the corresponding
     * flow until the user selects {@code 0} (exit).
     * </p>
     */
    public void runInteractive() {
        boolean running = true;
        while (running) {
            // show menu and wait for user's choice
            view.printMenu();
            int choice = view.readInt("");

            // perform action based on user's selection
            switch (choice) {
                case 1 -> addFlow(); // add new meteorite
                case 2 -> view.showList(repo.findAll()); // list all
                case 3 -> view.showHeaviest(repo.findHeaviest()); // show heaviest
                case 4 -> statsFlow(); // show meteorite statistics
                case 5 -> searchFlow(); // search by name
                case 6 -> sortFlow();   // sort using selected key/order
                case 7 -> editFlow();   // edit by id
                case 8 -> deleteFlow(); // delete by id
                case 0 -> running = false; // exit loop
                default -> view.println("Unknown option.");
            }
        }
        view.println("Goodbye!");
    }

    /**
     * Flow: add a new meteorite.
     * <p>
     * Reads data from the user (name, mass, year) and tries to persist it via the
     * repository. Domain validation errors from the model are caught and presented
     * to the user as readable messages.
     * </p>
     */
    private void addFlow() {
        String name = view.readNonEmpty("Name: ");
        double mass = view.readDouble("Mass [g]: ");
        int year = view.readInt("Year of fall/discovery: ");
        try {
            repo.add(name, mass, year);
            view.println("Meteorite added.");
        } catch (com.mycompany.meteoryty.model.InvalidMeteoriteDataException ex) {
            view.println("Error: " + ex.getMessage());
        }
    }

    /**
     * Flow: statistics.
     * <p>
     * Retrieves all items, computes total and average mass using
     * {@link com.mycompany.meteoryty.model.MeteoriteStats}, and prints the summary.
     * </p>
     */
    private void statsFlow() {
        var list = repo.findAll();
        var stats = new com.mycompany.meteoryty.model.MeteoriteStats();
        double total = stats.totalMass(list);
        double avg = stats.averageMass(list);
        view.showStats(total, avg, list.size());
    }

    /**
     * Flow: search by name (case-insensitive substring).
     * <p>
     * Prompts for a query string, delegates to the repository and displays results.
     * </p>
     */
    private void searchFlow() {
        String q = view.readNonEmpty("Name contains: ");
        var results = repo.findByName(q);
        view.printlnFoundCount(results.size());
        view.showList(results);
    }

    /**
     * Flow: sorting.
     * <p>
     * Prompts the user to choose a sort key &amp; order, builds an appropriate
     * {@link Comparator} and prints the sorted copy of the list.
     * </p>
     */
    private void sortFlow() {
        int opt = view.printSortMenuAndReadChoice();

        // Explicit type to help the compiler and keep Comparator<Meteorite> inference clear
        List<Meteorite> list = repo.findAll();

        Comparator<Meteorite> cmp;

        switch (opt) {
            case 1 -> // Name ascending
                cmp = Comparator.comparing(
                        Meteorite::getName,
                        Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
                );
            case 2 -> // Name descending
                cmp = Comparator.comparing(
                        Meteorite::getName,
                        Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
                ).reversed();
            case 3 -> // Mass ascending
                cmp = Comparator.comparingDouble(Meteorite::getMassGrams);
            case 4 -> // Mass descending
                cmp = Comparator.comparingDouble(Meteorite::getMassGrams).reversed();
            case 5 -> // Year ascending
                cmp = Comparator.comparingInt(Meteorite::getYear);
            case 6 -> // Year descending
                cmp = Comparator.comparingInt(Meteorite::getYear).reversed();
            default ->
                cmp = Comparator.comparing(
                        Meteorite::getName,
                        Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
                );
        }

        list.sort(cmp);
        view.showList(list);
    }

    /**
     * Flow: edit an existing meteorite by id.
     * <p>
     * Loads the current entity, asks for new values and updates it in the model.
     * Domain validation errors (mass/year, and optionally name if validated in model)
     * are caught and shown to the user.
     * </p>
     */
    private void editFlow() {
        int id = view.readId("ID to edit: ");
        Meteorite current = repo.findById(id);
        if (current == null) {
            view.println("Meteorite with id #" + id + " not found.");
            return;
        }

        // Show current values
        view.println("Current: " + current);

        // Read new values (require all fields)
        String newName = view.readNonEmpty("New name: ");
        double newMass = view.readDouble("New mass [g]: ");
        int newYear = view.readInt("New year: ");

        try {
            com.mycompany.meteoryty.model.Meteorite updated =
                    repo.update(id, newName, newMass, newYear);
            if (updated != null) {
                view.println("Updated: " + updated);
            } else {
                view.println("Update failed (id not found).");
            }
        } catch (com.mycompany.meteoryty.model.InvalidMeteoriteDataException ex) {
            view.println("Error: " + ex.getMessage());
        }
    }

    /**
     * Flow: delete a meteorite by id (with confirmation).
     * <p>
     * Loads the entity, asks the user for confirmation and removes it from the repository.
     * Prints an informative message about the outcome.
     * </p>
     */
    private void deleteFlow() {
        int id = view.readId("ID to delete: ");
        Meteorite m = repo.findById(id);
        if (m == null) {
            view.println("Meteorite with id #" + id + " not found.");
            return;
        }

        view.println("To delete: " + m);
        boolean ok = view.confirm("Are you sure you want to delete this meteorite?");
        if (!ok) {
            view.println("Delete cancelled.");
            return;
        }

        boolean removed = repo.deleteById(id);
        view.println(removed ? "Deleted." : "Delete failed (id not found).");
    }

    /**
     * Helper: returns a lower-cased string (null-safe).
     *
     * @param s input string (may be {@code null})
     * @return lower-cased string, or {@code null} if input was {@code null}
     */
    private static String safeLower(String s) {
        return (s == null) ? null : s.toLowerCase();
    }
}
