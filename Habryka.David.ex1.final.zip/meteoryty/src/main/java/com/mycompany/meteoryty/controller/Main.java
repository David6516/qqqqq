package com.mycompany.meteoryty.controller;

import com.mycompany.meteoryty.model.MeteoriteRepository;
import com.mycompany.meteoryty.view.ConsoleView;

/**
 * Entry point of the Meteorite Database application.
 *
 * <p>
 * This class initializes the MVC components:
 * <ul>
 *   <li>{@link MeteoriteRepository} — the Model, responsible for storing data,</li>
 *   <li>{@link ConsoleView} — the View, responsible for console I/O,</li>
 *   <li>{@link AppController} — the Controller, which coordinates interaction between Model and View.</li>
 * </ul>
 *
 * <h2>Modes of operation</h2>
 * The program supports:
 * <ul>
 *   <li><b>Command-line mode</b> — if exactly three parameters are provided,
 *       a meteorite is added to the repository before entering interactive mode.</li>
 *   <li><b>Interactive console mode</b> — if parameters are missing or invalid,
 *       the program automatically switches to an interactive menu.</li>
 * </ul>
 *
 * <h3>Command-line parameters (order)</h3>
 * <pre>
 *   java com.mycompany.meteoryty.controller.Main &lt;name&gt; &lt;massGrams&gt; &lt;year&gt;
 *
 *   where:
 *     &lt;name&gt;      - meteorite name (String; use quotes if it contains spaces)
 *     &lt;massGrams&gt; - meteorite mass in grams (double; decimal separator: dot)
 *     &lt;year&gt;      - year of fall/discovery (int)
 *
 *   examples:
 *     java com.mycompany.meteoryty.controller.Main "Chelyabinsk" 10000 2013
 *     java com.mycompany.meteoryty.controller.Main Aletai 328000 1898
 * </pre>
 *
 * <p><b>Behavior:</b>
 * <ul>
 *   <li>If 3 parameters are provided and parsing is successful — the meteorite
 *       is added and a confirmation message is printed.</li>
 *   <li>If the number of parameters is incorrect, or parsing fails —
 *       the program prints a notice and starts interactive mode.</li>
 * </ul>
 *
 * @author David Habryka
 * @version 2.0
 */
public class Main {

    /**
     * Program entry point.
     *
     * <p>
     * Initializes MVC components, processes optional command-line arguments,
     * and then starts the interactive menu via {@link AppController#runInteractive()}.
     *
     * @param args optional command-line parameters:
     *             {@code <name> <massGrams> <year>}.
     *             If parsing fails or parameters are missing,
     *             the program will switch to interactive mode automatically.
     * @throws NumberFormatException if provided numeric arguments are not valid numbers
     * @see AppController
     * @see MeteoriteRepository
     * @see ConsoleView
     */
    public static void main(String[] args) {
        // Initialize Model, View, and Controller
        MeteoriteRepository repo = new MeteoriteRepository();
        ConsoleView view = new ConsoleView();
        AppController controller = new AppController(repo, view);

        // Display banner
        view.println("======================================");
        view.println("  Meteorite Database — Prototype (MVC)");
        view.println("======================================");

        // --- Command-line branch (optional) ---
        boolean shouldShowCliNotice = false;

        if (args != null && args.length == 3) {
            String name = args[0];
            String massStr = args[1];
            String yearStr = args[2];

            try {
                double mass = Double.parseDouble(massStr); // decimal separator: dot
                int year = Integer.parseInt(yearStr);

                try {
                    repo.add(name, mass, year);
                    view.println("Added from CLI: " + name + " (" + String.format("%.0f", mass) + " g, " + year + ")");
                    view.println("Total items: " + repo.count());
                    view.println("[CLI] Meteorite added. Entering interactive mode...");
                } catch (com.mycompany.meteoryty.model.InvalidMeteoriteDataException ex) {
                    view.println("[CLI] Invalid data: " + ex.getMessage());
                    view.println("[CLI] Switching to interactive mode...");
                }

            } catch (NumberFormatException ex) {
                shouldShowCliNotice = true;
                view.println("[CLI] Invalid number format for <massGrams> or <year>.");
                view.println("[CLI] Switching to interactive mode...");
            }
        } else if (args != null && args.length != 3) {
            shouldShowCliNotice = true;
            view.println("[CLI] Wrong number of parameters. Expected: <name> <massGrams> <year>");
            view.println("[CLI] Switching to interactive mode...");
        }

        // --- Interactive mode (default or after CLI processing) ---
        if (!shouldShowCliNotice) {
            view.println(""); // spacing after CLI success (optional)
        }
        controller.runInteractive();

        // Exit
        view.println("Program finished. Goodbye!");
    }
}
