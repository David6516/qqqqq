package com.mycompany.meteoryty.controller;

import com.mycompany.meteoryty.model.MeteoriteRepository;
import javax.swing.SwingUtilities;

/**
 * Main entry point of the application.
 * <p>
 * Initializes the repository, controller, and GUI view. The GUI is started on
 * the Event Dispatch Thread using {@link SwingUtilities#invokeLater(Runnable)}
 * to ensure thread-safe UI operations.
 */
public class Main {

    /**
     * Launches the meteorite application.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {

        // Initialize the data repository (in-memory or backed by storage, depending on implementation)
        MeteoriteRepository repo = new MeteoriteRepository();

        // Run GUI creation on the Swing Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            GuiController gc = new GuiController(repo);

            // Create and display the GUI window
            new com.mycompany.meteoryty.view.GuiView(gc).showWindow();
        });
    }
}
