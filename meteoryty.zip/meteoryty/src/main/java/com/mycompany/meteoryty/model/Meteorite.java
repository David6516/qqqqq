package com.mycompany.meteoryty.model;

/**
 * Represents a single meteorite entry in the database.
 *
 * <p>
 * Each meteorite has a unique identifier, name, mass (in grams),
 * and the year of fall or discovery.
 * This class serves as a simple data model within the MVC architecture.
 *
 * <p>
 * Example textual representation produced by {@link #toString()}:
 * <pre>#1 Chelyabinsk (10000 g, 2013)</pre>
 *
 * @author David Habryka
 * @version 2.0
 */
public class Meteorite {

    /** Unique meteorite identifier (auto-incremented in the repository). */
    private final int id;

    /** Meteorite name. */
    private String name;

    /** Mass of the meteorite in grams. */
    private double massGrams;

    /** Year of fall or discovery. */
    private int year;

    /**
     * Constructs a new {@code Meteorite} object with the specified attributes.
     *
     * @param id         unique meteorite identifier
     * @param name       meteorite name (non-null)
     * @param massGrams  meteorite mass in grams (positive number)
     * @param year       year of fall or discovery
     */
    public Meteorite(int id, String name, double massGrams, int year) {
        this.id = id;
        this.name = name;
        this.massGrams = massGrams;
        this.year = year;
    }

    /**
     * Returns the unique identifier of this meteorite.
     *
     * @return meteorite ID
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the name of the meteorite.
     *
     * @return meteorite name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the mass of the meteorite in grams.
     *
     * @return meteorite mass (grams)
     */
    public double getMassGrams() {
        return massGrams;
    }

    /**
     * Returns the year when the meteorite was found or observed.
     *
     * @return year of fall/discovery
     */
    public int getYear() {
        return year;
    }

    /**
     * Updates the meteorite name.
     *
     * @param name new name to assign (non-empty string)
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Updates the meteorite mass.
     *
     * @param massGrams new mass in grams (must be positive)
     */
    public void setMassGrams(double massGrams) {
        this.massGrams = massGrams;
    }

    /**
     * Updates the meteorite year.
     *
     * @param year new year of fall/discovery
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * Returns a formatted string representation of this meteorite.
     *
     * <p>Example output:
     * <pre>#3 Aletai (328000 g, 1898)</pre>
     *
     * @return formatted text containing ID, name, mass and year
     */
    @Override
    public String toString() {
        return String.format("#%d %s (%.0f g, %d)", id, name, massGrams, year);
        // String.format uses:
        // %d = integer (id, year)
        // %s = string (name)
        // %.0f = floating-point number without decimals (mass)
    }
}
