package com.mycompany.meteoryty.controller;

import com.mycompany.meteoryty.exception.InvalidMeteoriteDataException;
import com.mycompany.meteoryty.model.Meteorite;
import com.mycompany.meteoryty.model.MeteoriteRepository;

import java.util.List;
import java.util.Objects;

/**
 * GUI controller acting as a bridge between the presentation layer and the meteorite repository.
 * <p>
 * Provides methods for retrieving, adding, updating, deleting, and searching meteorites,
 * as well as generating simple statistics.
 *
 * <h2>Design Notes</h2>
 * <ul>
 *   <li>This class is a thin facade — business logic is primarily located in {@link MeteoriteRepository}
 *       and supporting classes (e.g., {@code MeteoriteStats}).</li>
 *   <li>No transaction handling or validation is performed here aside from delegation to the repository.</li>
 *   <li>The controller contains no internal state other than a reference to the repository, so it is
 *       safe to reuse assuming the repository implementation is thread-safe.</li>
 * </ul>
 */
public class GuiController {

    /** Repository backing this controller. Cannot be {@code null}. */
    private final MeteoriteRepository repo;

    /**
     * Creates a controller for a given repository.
     *
     * @param repo the meteorite repository instance; must not be {@code null}
     * @throws NullPointerException if {@code repo} is {@code null}
     */
    public GuiController(MeteoriteRepository repo) {
        this.repo = Objects.requireNonNull(repo);
    }

    /**
     * Retrieves all meteorites stored in the repository.
     *
     * @return a list of all meteorites; may be empty, but never {@code null}
     */
    public List<Meteorite> getAll() {
        return repo.findAll();
    }

    /**
     * Adds a new meteorite to the repository.
     *
     * @param name the meteorite name; must not be empty
     * @param mass the meteorite mass; must be positive
     * @param year the year of fall/discovery; expected to be within a reasonable historical range
     * @return the newly created meteorite (with ID assigned if applicable)
     * @throws InvalidMeteoriteDataException if input data is invalid (e.g., empty name, negative mass)
     */
    public Meteorite add(String name, double mass, int year) throws InvalidMeteoriteDataException {
        return repo.add(name, mass, year);
    }

    /**
     * Finds the heaviest meteorite in the repository.
     *
     * @return the heaviest meteorite, or {@code null} if the repository is empty
     */
    public Meteorite findHeaviest() {
        return repo.findHeaviest();
    }

    /**
     * Updates an existing meteorite.
     *
     * @param id   the ID of the meteorite to update
     * @param name new name; must not be empty
     * @param mass new mass; must be positive
     * @param year new year; expected to be valid as in {@link #add(String, double, int)}
     * @return the updated meteorite
     * @throws InvalidMeteoriteDataException if validation fails or the record does not exist 
     *                                      (depending on repository behavior)
     */
    public Meteorite update(int id, String name, double mass, int year) throws InvalidMeteoriteDataException {
        return repo.update(id, name, mass, year);
    }

    /**
     * Deletes a meteorite by ID.
     *
     * @param id the ID of the meteorite to delete
     * @return {@code true} if a meteorite was deleted; {@code false} if no such ID existed
     */
    public boolean delete(int id) {
        return repo.deleteById(id);
    }

    /**
     * Searches meteorites by name (partial match depending on repository rules).
     *
     * @param query the name fragment to search for; should not be empty
     * @return list of matching meteorites; may be empty, never {@code null}
     */
    public List<Meteorite> findByName(String query) {
        return repo.findByName(query);
    }

    /**
     * Simple immutable DTO containing meteorite statistics.
     * <p>
     * This class does not compute values itself; it only holds the result of calculations.
     */
    public static final class Stats {

        /** Number of meteorites. */
        public final int count;

        /** Sum of masses. Units depend on repository conventions. */
        public final double totalMass;

        /** Average mass. Units depend on repository conventions. */
        public final double averageMass;

        /**
         * Creates a new statistics object.
         *
         * @param count       total number of meteorites
         * @param totalMass   total mass
         * @param averageMass average mass
         */
        public Stats(int count, double totalMass, double averageMass) {
            this.count = count;
            this.totalMass = totalMass;
            this.averageMass = averageMass;
        }
    }

    /**
     * Calculates statistics for all meteorites currently stored in the repository.
     *
     * @return a {@link Stats} object containing count, total mass, and average mass
     */
    public Stats stats() {
        var list = repo.findAll();
        var ms = new com.mycompany.meteoryty.model.MeteoriteStats();
        double total = ms.totalMass(list);
        double avg = ms.averageMass(list);
        return new Stats(list.size(), total, avg);
    }
}
