package com.mycompany.meteoryty.view;

import com.mycompany.meteoryty.model.Meteorite;
import java.util.List;
import java.util.Scanner;

/**
 * Console-based user interface for the Meteorite Database application.
 *
 * <p>
 * This class is the <b>View</b> component in the MVC architecture.
 * It is responsible for:
 * <ul>
 *   <li>displaying menus and messages,</li>
 *   <li>reading user input from the console,</li>
 *   <li>showing meteorite data and statistics.</li>
 * </ul>
 *
 * <p>
 * All input validation (for numeric or non-empty text fields) is handled
 * interactively by repeatedly prompting the user until valid input is entered.
 *
 * @author David Habryka
 * @version 2.0
 * @see com.mycompany.meteoryty.model.Meteorite
 * @see com.mycompany.meteoryty.controller.AppController
 */
public class ConsoleView {

    /** Scanner used to read user input from the console. */
    private final Scanner in = new Scanner(System.in);

    /**
     * Prints a line of text to the console.
     *
     * @param s message to display
     */
    public void println(String s) {
        System.out.println(s);
    }

    /**
     * Displays the main menu options for the application.
     * Called repeatedly from the controller’s main loop.
     */
    public void printMenu() {
        System.out.println("\n=== Meteorite Database ===");
        System.out.println("1) Add meteorite");
        System.out.println("2) Show all");
        System.out.println("3) Heaviest meteorite");
        System.out.println("4) Statistics");
        System.out.println("5) Search by name");
        System.out.println("6) Sort");
        System.out.println("7) Edit meteorite");
        System.out.println("8) Delete meteorite");
        System.out.println("0) Exit");
        System.out.print("Choice: ");
    }

    /**
     * Reads an integer value from the user, looping until valid input is entered.
     *
     * @param prompt text shown before input
     * @return the integer value entered by the user
     */
    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine();
            try {
                return Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number!");
            }
        }
    }

    /**
     * Reads a double value from the user, accepting both commas and dots as decimal separators.
     *
     * @param prompt text shown before input
     * @return the double value entered by the user
     */
    public double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine().replace(',', '.');
            try {
                return Double.parseDouble(s.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number (e.g. 1234.5)!");
            }
        }
    }

    /**
     * Reads a non-empty string from the user.
     * Loops until a non-blank line is entered.
     *
     * @param prompt text shown before input
     * @return the non-empty string entered by the user
     */
    public String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Meteorite name cannot be empty!");
        }
    }

    /**
     * Displays a formatted list of meteorites in the console.
     *
     * @param list list of {@link Meteorite} objects to display
     */
    public void showList(List<Meteorite> list) {
        if (list.isEmpty()) {
            System.out.println("(empty)");
        } else {
            list.forEach(m -> System.out.println(" - " + m));
        }
    }

    /**
     * Displays the heaviest meteorite or a message if no data is available.
     *
     * @param m the meteorite object to display, or {@code null} if none exists
     */
    public void showHeaviest(Meteorite m) {
        if (m == null) {
            System.out.println("No data.");
        } else {
            System.out.println("Heaviest: " + m);
        }
    }

    /**
     * Displays the sorting submenu and reads the user's choice (1–6).
     *
     * @return integer value between 1 and 6 representing the chosen sorting option
     */
    public int printSortMenuAndReadChoice() {
        System.out.println("Sort by:");
        System.out.println("1) Name ascending");
        System.out.println("2) Name descending");
        System.out.println("3) Mass ascending");
        System.out.println("4) Mass descending");
        System.out.println("5) Year ascending");
        System.out.println("6) Year descending");
        while (true) {
            int opt = readInt("Choice (1-6): ");
            if (opt >= 1 && opt <= 6) return opt;
            System.out.println("Please choose 1..6.");
        }
    }

    /**
     * Prints how many results were found in a search.
     *
     * @param n number of found meteorites
     */
    public void printlnFoundCount(int n) {
        System.out.println("Found: " + n);
    }

    /**
     * Displays total and average mass statistics for the given collection.
     *
     * @param totalMassGrams total mass in grams
     * @param averageMassGrams average mass in grams
     * @param count number of meteorites
     */
    public void showStats(double totalMassGrams, double averageMassGrams, int count) {
        if (count == 0) {
            System.out.println("No data.");
            return;
        }
        System.out.printf("Count: %d%n", count);
        System.out.printf("Total mass: %.0f g%n", totalMassGrams);
        System.out.printf("Average mass: %.2f g%n", averageMassGrams);
    }

    /**
     * Asks the user for confirmation (yes/no).
     *
     * @param prompt question to display
     * @return {@code true} if user types 'y' or 'Y'; {@code false} otherwise
     */
    public boolean confirm(String prompt) {
        while (true) {
            System.out.print(prompt + " [y/n]: ");
            String s = in.nextLine().trim().toLowerCase();
            if (s.equals("y")) return true;
            if (s.equals("n")) return false;
            System.out.println("Please type 'y' or 'n'.");
        }
    }

    /**
     * Reads a valid positive integer ID (≥ 1) from the user.
     *
     * @param prompt message to display before input
     * @return valid meteorite ID
     */
    public int readId(String prompt) {
        while (true) {
            int id = readInt(prompt);
            if (id >= 1) return id;
            System.out.println("ID must be >= 1.");
        }
    }
}
