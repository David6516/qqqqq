package com.mycompany.meteoryty.view;

import com.mycompany.meteoryty.controller.GuiController;
import com.mycompany.meteoryty.exception.InvalidMeteoriteDataException;
import com.mycompany.meteoryty.model.Meteorite;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.text.AbstractDocument;
import javax.swing.text.DocumentFilter;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Main GUI window (Swing) of the Meteorite application.
 *
 * <p><b>Features</b>:
 * <ul>
 *   <li>CRUD: Add (Ctrl+N), Edit (Ctrl+E / double-click row), Delete (Del)</li>
 *   <li>Heaviest (Ctrl+H), Stats (Ctrl+T)</li>
 *   <li>Filtering by name (“Pattern”): focus (Ctrl+F), apply (Enter), reset (Ctrl+R)</li>
 *   <li>Sorting by Name/Mass/Year + Asc/Desc (auto-applied on change)</li>
 *   <li>ID column hidden in the table (kept in model, removed from view)</li>
 * </ul>
 *
 * <p><b>Accessibility</b>:
 * tooltips, mnemonics (Alt+key), AccessibleName/Description and logical Tab navigation.
 *
 * <p><b>Validation</b> (soft, in dialog):
 * Mass allows only digits and one dot; Year allows digits only (4 chars); dialog does not close on error;
 * mass must be finite and > 0; year must be in [1400, 2100].
 *
 * <p><b>Domain rules</b> are still enforced in the model and may throw
 * {@link com.mycompany.meteoryty.exception.InvalidMeteoriteDataException}.
 */
public class GuiView extends JFrame {

    // ====== Main view fields ======

    /** Controller – the bridge between GUI and repository. */
    private final GuiController controller;

    /** Table model (data source for JTable). */
    private final MeteoriteTableModel tableModel = new MeteoriteTableModel();
    /** JTable bound to the model. */
    private final JTable table = new JTable(tableModel);
    /** Status bar at the bottom. */
    private final JLabel status = new JLabel("Ready");
    /** Filter field (substring, case-insensitive, matches name). */
    private final JTextField tfSearch = new JTextField(16);

    // --- sort UI (combos: key + order) ---
    private final JComboBox<String> cbSortKey =
            new JComboBox<>(new String[]{"Name", "Mass", "Year"});
    private final JComboBox<String> cbSortOrder =
            new JComboBox<>(new String[]{"Ascending", "Descending"});

    /**
     * Creates and initializes the main GUI window.
     */
    public GuiView(GuiController controller) {
        super("Meteorite Database — GUI (Minimal)");
        this.controller = controller;

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8)); // 8px gaps

        // Create Actions (labels + shortcuts) and wire them to menu/toolbar
        var actions = createActions();
        setJMenuBar(buildMenuBar(actions)); // top menu

        // North area: toolbar + filter panel + sort panel
        var north = new JPanel(new BorderLayout());
        north.add(buildToolBar(actions), BorderLayout.NORTH);
        north.add(buildSearchPanel(actions), BorderLayout.CENTER);
        north.add(buildSortPanel(actions), BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);

        // Global Alt+F4 binding (works regardless of focus); delegates to Exit action
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke("alt F4"), "app-exit");
        getRootPane().getActionMap()
                .put("app-exit", new AbstractAction() {
                    @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                        actions.exit.actionPerformed(e);
                    }
                });

        // Table setup + accessibility
        table.setFillsViewportHeight(true);
        table.getAccessibleContext().setAccessibleName("Meteorites table");
        table.getAccessibleContext().setAccessibleDescription("Table listing meteorites (id, name, mass, year)");

        // Remove ID column only from the VIEW (model still has it and methods keep working)
        if (table.getColumnModel().getColumnCount() > 0) {
            table.removeColumn(table.getColumnModel().getColumn(0));
        }

        // UX hint and double-click -> edit
        table.setToolTipText("Double-click a row to edit");
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (!SwingUtilities.isLeftMouseButton(e)) return;
                if (e.getClickCount() != 2) return;
                int viewRow = table.rowAtPoint(e.getPoint());
                if (viewRow < 0) return;
                table.getSelectionModel().setSelectionInterval(viewRow, viewRow);
                onEditSelected(); // reuse existing handler
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Status bar (bottom)
        status.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        add(status, BorderLayout.SOUTH);

        // Initial load and refresh
        reloadAll();

        setMinimumSize(new Dimension(720, 460));
        setLocationRelativeTo(null);
    }

    /** Shows the window. */
    public void showWindow() { setVisible(true); }

    // ====== Actions ======

    /** Keeps all Swing Actions in one place. */
    private static final class ActionMapBundle {
        Action add, edit, delete, heaviest, searchFocus, searchRun, reset, stats, exit;
    }

    /**
     * Creates and describes actions (label, tooltip, mnemonic, accelerators) and binds handlers.
     */
    private ActionMapBundle createActions() {
        var a = new ActionMapBundle();

        // Add: create new row; Ctrl+N, Alt+A
        a.add = new AbstractAction("Add") {
            { putValue(SHORT_DESCRIPTION, "Add new meteorite (Ctrl+N)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_A);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onAdd(); }
        };

        // Edit: edit selected row; Ctrl+E, Alt+E
        a.edit = new AbstractAction("Edit") {
            { putValue(SHORT_DESCRIPTION, "Edit selected meteorite (Ctrl+E / double-click row)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_E);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onEditSelected(); }
        };

        // Delete: delete selected row; Del, Alt+D
        a.delete = new AbstractAction("Delete") {
            { putValue(SHORT_DESCRIPTION, "Delete selected meteorite (Del)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_D);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("DELETE")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onDeleteSelected(); }
        };

        // Heaviest: select and show heaviest row; Ctrl+H, Alt+H
        a.heaviest = new AbstractAction("Heaviest") {
            { putValue(SHORT_DESCRIPTION, "Show and select heaviest meteorite (Ctrl+H)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_H);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control H")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onHeaviest(); }
        };

        // Pattern (focus): go to filter field; Ctrl+F, Alt+P
        a.searchFocus = new AbstractAction("Pattern") {
            { putValue(SHORT_DESCRIPTION, "Focus pattern field (Ctrl+F)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_P);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control F")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onSearchFocus(); }
        };

        // Filter: apply current pattern; Enter in field or click; Alt+F
        a.searchRun = new AbstractAction("Filter") {
            { putValue(SHORT_DESCRIPTION, "Filter rows by name pattern (Enter)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_F); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onSearchNow(); }
        };

        // Reset: clear pattern; Ctrl+R, Alt+R
        a.reset = new AbstractAction("Reset") {
            { putValue(SHORT_DESCRIPTION, "Clear filter and show all (Ctrl+R)");
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control R"));
              putValue(MNEMONIC_KEY, KeyEvent.VK_R); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onResetSearch(); }
        };

        // Stats: show simple stats; Ctrl+T, Alt+T
        a.stats = new AbstractAction("Stats") {
            { putValue(SHORT_DESCRIPTION, "Show count, total mass and average mass (Ctrl+T)");
              putValue(MNEMONIC_KEY, KeyEvent.VK_T);
              putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control T")); }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { onStats(); }
        };

        // Exit: quit application; Ctrl+Q (+ global Alt+F4)
        a.exit = new AbstractAction("Exit") {
            {
                putValue(SHORT_DESCRIPTION, "Close the application (Ctrl+Q / Alt+F4)");
                putValue(MNEMONIC_KEY, KeyEvent.VK_X);
                putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(
                        KeyEvent.VK_Q,
                        Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()
                ));
            }
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                System.exit(0);
            }
        };

        return a;
    }

    // ====== Menu / toolbar / panels ======

    /** Builds the main menu (Actions) – using the same Actions as the toolbar. */
    private JMenuBar buildMenuBar(ActionMapBundle a) {
        var bar = new JMenuBar();
        var m = new JMenu("Actions");
        m.setMnemonic(KeyEvent.VK_C); // Alt+C
        m.add(new JMenuItem(a.add));
        m.add(new JMenuItem(a.edit));
        m.add(new JMenuItem(a.delete));
        m.add(new JMenuItem(a.heaviest));
        m.addSeparator();
        m.add(new JMenuItem(a.searchFocus));
        m.add(new JMenuItem(a.searchRun));
        m.add(new JMenuItem(a.reset));
        m.add(new JMenuItem(a.stats));
        m.addSeparator();
        m.add(new JMenuItem(a.exit));
        bar.add(m);
        return bar;
    }

    /** Builds the main toolbar (buttons are backed by Actions). */
    private JToolBar buildToolBar(ActionMapBundle a) {
        var tb = new JToolBar();
        tb.setFloatable(false);

        var bAdd = tb.add(a.add);
        var bEdit = tb.add(a.edit);
        var bDelete = tb.add(a.delete);

        var bHeaviest = tb.add(a.heaviest);
        var bStats = tb.add(a.stats);
        bStats.setToolTipText("Stats (Ctrl+T)");
        bStats.getAccessibleContext().setAccessibleName("Stats");
        bStats.getAccessibleContext().setAccessibleDescription("Show total and average mass statistics");

        tb.addSeparator();
        var bExit = tb.add(a.exit);
        bExit.setToolTipText("Exit (Ctrl+Q / Alt+F4)");

        bAdd.setToolTipText("Add new meteorite (Ctrl+N)");
        bHeaviest.setToolTipText("Show heaviest meteorite (Ctrl+H)");
        bEdit.setToolTipText("Edit selected (Ctrl+E / double-click row)");
        bDelete.setToolTipText("Delete selected (Del)");

        tb.getAccessibleContext().setAccessibleName("Main toolbar");
        tb.getAccessibleContext().setAccessibleDescription("Toolbar with core actions (add, edit, delete, heaviest, stats, exit)");
        return tb;
    }

    /** Builds the filter panel (by name substring, case-insensitive). */
    private JComponent buildSearchPanel(ActionMapBundle a) {
        var p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));

        var l = new JLabel("Pattern:");
        l.setDisplayedMnemonic(KeyEvent.VK_P);
        l.setLabelFor(tfSearch);

        tfSearch.setToolTipText("Case-insensitive name pattern (substring)");
        tfSearch.getAccessibleContext().setAccessibleName("Pattern field");
        tfSearch.getAccessibleContext().setAccessibleDescription("Enter name fragment to filter rows");

        // Pressing Enter in the field applies the filter
        tfSearch.addActionListener(e -> onSearchNow());

        var bFind = new JButton(a.searchRun);
        bFind.setToolTipText("Apply filter (Enter)");
        bFind.getAccessibleContext().setAccessibleName("Filter button");
        bFind.getAccessibleContext().setAccessibleDescription("Filter table by name pattern");

        var bReset = new JButton(a.reset);
        bReset.setToolTipText("Reset filter (Ctrl+R)");
        bReset.getAccessibleContext().setAccessibleName("Reset filter button");
        bReset.getAccessibleContext().setAccessibleDescription("Clear pattern and show all records");

        p.add(l);
        p.add(tfSearch);
        p.add(bFind);
        p.add(bReset);

        p.getAccessibleContext().setAccessibleName("Filter panel");
        p.getAccessibleContext().setAccessibleDescription("Filtering tools for the table");
        return p;
    }

    /** Builds the sort panel: field + order; auto-applies sorting on every change. */
    private JComponent buildSortPanel(ActionMapBundle a) {
        var p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));

        var lKey = new JLabel("Sort by:");
        lKey.setDisplayedMnemonic(KeyEvent.VK_B); // Alt+B
        lKey.setLabelFor(cbSortKey);

        cbSortKey.setToolTipText("Sort key");
        cbSortKey.getAccessibleContext().setAccessibleName("Sort key");
        cbSortKey.getAccessibleContext().setAccessibleDescription("Choose field to sort by");

        var lOrder = new JLabel("Order:");
        lOrder.setDisplayedMnemonic(KeyEvent.VK_O); // Alt+O
        lOrder.setLabelFor(cbSortOrder);

        cbSortOrder.setToolTipText("Sort order");
        cbSortOrder.getAccessibleContext().setAccessibleName("Sort order");
        cbSortOrder.getAccessibleContext().setAccessibleDescription("Choose ascending or descending");

        // Auto-sort: any change in combos immediately sorts the view
        java.awt.event.ActionListener autoSort = e -> applyCurrentSort();
        cbSortKey.addActionListener(autoSort);
        cbSortOrder.addActionListener(autoSort);

        p.add(lKey);
        p.add(cbSortKey);
        p.add(lOrder);
        p.add(cbSortOrder);

        p.getAccessibleContext().setAccessibleName("Sort panel");
        p.getAccessibleContext().setAccessibleDescription("Controls for sorting the table");
        return p;
    }

    // ====== Action handlers ======

    /** Reloads data from the controller, updates the status bar, and reapplies current sort. */
    private void reloadAll() {
        tableModel.setRows(controller.getAll());
        status.setText("Items: " + tableModel.getRowCount());
        applyCurrentSort();
    }

    /** Opens the modal form and adds a record (soft-validation in dialog, hard-validation in model). */
    private void onAdd() {
        var form = new MeteoriteForm(this, "Add meteorite");
        var data = form.showDialog();
        if (data == null) return;
        try {
            controller.add(data.name, data.mass, data.year);
            reloadAll();
            status.setText("Added: " + data.name);
        } catch (InvalidMeteoriteDataException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid data", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Selects and shows the heaviest item (if any). */
    private void onHeaviest() {
        var m = controller.findHeaviest();
        if (m == null) {
            JOptionPane.showMessageDialog(this, "No data.", "Heaviest", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int idx = tableModel.indexOfId(m.getId());
        if (idx >= 0) {
            table.getSelectionModel().setSelectionInterval(idx, idx);
            table.scrollRectToVisible(table.getCellRect(idx, 0, true));
        }
        JOptionPane.showMessageDialog(this, "Heaviest: " + m, "Heaviest", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Opens a prefilled edit dialog for the selected row and updates it on confirm. */
    private void onEditSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a row to edit.", "Edit", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        var m = tableModel.getAt(row);

        var form = new MeteoriteForm(this, "Edit meteorite", m.getName(), m.getMassGrams(), m.getYear());
        var data = form.showDialog();
        if (data == null) return;

        try {
            controller.update(m.getId(), data.name, data.mass, data.year);
            reloadAll();
            int idx = tableModel.indexOfId(m.getId());
            if (idx >= 0) {
                table.getSelectionModel().setSelectionInterval(idx, idx);
                table.scrollRectToVisible(table.getCellRect(idx, 0, true));
            }
            status.setText("Updated: #" + m.getId());
        } catch (InvalidMeteoriteDataException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid data", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Confirms and deletes the selected row, if any. */
    private void onDeleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a row to delete.", "Delete", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        var m = tableModel.getAt(row);
        int res = JOptionPane.showConfirmDialog(this, "Delete: " + m + " ?", "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (res != JOptionPane.YES_OPTION) return;

        if (controller.delete(m.getId())) {
            reloadAll();
            status.setText("Deleted: #" + m.getId());
        } else {
            JOptionPane.showMessageDialog(this, "Delete failed (id not found).", "Delete", JOptionPane.WARNING_MESSAGE);
        }
    }

    /** Focuses the filter field and selects its content for quick overwrite. */
    private void onSearchFocus() {
        tfSearch.requestFocusInWindow();
        tfSearch.selectAll();
        status.setText("Type name and press Enter or 'Filter'.");
    }

    /** Applies current filter; empty pattern restores full list. */
    private void onSearchNow() {
        String q = tfSearch.getText().trim();
        if (q.isEmpty()) {
            reloadAll();
            status.setText("Filter cleared. Showing all.");
            return;
        }
        var results = controller.findByName(q);
        tableModel.setRows(results);
        applyCurrentSort();
        status.setText("Filtered: " + results.size());
    }

    /** Clears the pattern and reloads the full list. */
    private void onResetSearch() {
        tfSearch.setText("");
        reloadAll();
        status.setText("Reset filter.");
    }

    /** Shows count, total mass and average mass for current repository data. */
    private void onStats() {
        var s = controller.stats();
        if (s.count == 0) {
            JOptionPane.showMessageDialog(this, "No data.", "Stats", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String msg = String.format(
                "Count: %d%nTotal mass: %.0f g%nAverage mass: %.2f g",
                s.count, s.totalMass, s.averageMass
        );
        JOptionPane.showMessageDialog(this, msg, "Stats", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Applies current sort (key + order) to a copy of table rows.
     * Works on a copy (getRowsCopy), sorts it, then injects back into the model.
     * Called after any combo change and after reload.
     */
    private void applyCurrentSort() {
        if (tableModel.getRowCount() == 0) {
            status.setText("Items: 0");
            return;
        }
        String key   = String.valueOf(cbSortKey.getSelectedItem());
        String order = String.valueOf(cbSortOrder.getSelectedItem());

        java.util.List<Meteorite> list = tableModel.getRowsCopy();

        java.util.Comparator<Meteorite> cmp = switch (key) {
            case "Name" -> java.util.Comparator.comparing(
                    Meteorite::getName,
                    java.util.Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER));
            case "Mass" -> java.util.Comparator.comparingDouble(Meteorite::getMassGrams);
            case "Year" -> java.util.Comparator.comparingInt(Meteorite::getYear);
            default -> java.util.Comparator.comparing(
                    Meteorite::getName,
                    java.util.Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER));
        };
        if ("Descending".equalsIgnoreCase(order)) cmp = cmp.reversed();

        list.sort(cmp);
        tableModel.setRows(list);
        status.setText("Sorted by " + key + " (" + order.toLowerCase() + ")");
    }

    // ====== Table model ======

    /**
     * TableModel holding Meteorite rows for the JTable.
     * Columns (in the model): ID, Name, Mass [g], Year — the ID column is hidden in the view (removeColumn).
     */
    private static final class MeteoriteTableModel extends AbstractTableModel {
        private final String[] cols = {"ID", "Name", "Mass [g]", "Year"};
        private List<Meteorite> rows = new ArrayList<>();

        /** Replaces current rows with a fresh copy and repaints the table. */
        public void setRows(List<Meteorite> newRows) {
            this.rows = new ArrayList<>(newRows);
            fireTableDataChanged();
        }

        /** Returns a shallow copy of current rows — safe for local sorting/filtering. */
        public java.util.List<Meteorite> getRowsCopy() {
            return new java.util.ArrayList<>(rows);
        }

        /** Finds row index by meteorite id; -1 when not found (useful for selection). */
        public int indexOfId(int id) {
            for (int i = 0; i < rows.size(); i++) if (rows.get(i).getId() == id) return i;
            return -1;
        }

        /** Returns meteorite at given row index (used by edit). */
        public Meteorite getAt(int row) { return rows.get(row); }

        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int column) { return cols[column]; }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            var m = rows.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> m.getId();
                case 1 -> m.getName();
                case 2 -> m.getMassGrams();
                case 3 -> m.getYear();
                default -> null;
            };
        }

        @Override public Class<?> getColumnClass(int columnIndex) {
            return switch (columnIndex) {
                case 0, 3 -> Integer.class;
                case 2 -> Double.class;
                default -> String.class;
            };
        }
    }

    // ====== Add/Edit dialog ======

    /**
     * Modal dialog for adding/editing a single meteorite.
     * Soft validation (DocumentFilter + messages) – the dialog does NOT close on error.
     */
    private static final class MeteoriteForm extends JDialog {

        /** Simple immutable container for form data. */
        static final class Data {
            final String name; final double mass; final int year;
            Data(String name, double mass, int year) { this.name = name; this.mass = mass; this.year = year; }
        }

        /** Result is set after OK; {@code null} when canceled. */
        private Data result;

        private final JTextField tfName = new JTextField(20);
        private final JTextField tfMass = new JTextField(10);
        private final JTextField tfYear = new JTextField(8);

        private static void setFilter(JTextField field, DocumentFilter filter) {
            ((AbstractDocument) field.getDocument()).setDocumentFilter(filter);
        }

        // MaxLengthFilter: limits text length (e.g., Name to 60 chars)
        private static final class MaxLengthFilter extends DocumentFilter {
            private final int max;
            MaxLengthFilter(int max) { this.max = max; }
            @Override public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) return;
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String next = new StringBuilder(cur).insert(offset, string).toString();
                if (next.length() <= max) super.insertString(fb, offset, string, attr);
            }
            @Override public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String next = new StringBuilder(cur).replace(offset, offset + length, text == null ? "" : text).toString();
                if (next.length() <= max) super.replace(fb, offset, length, text, attrs);
            }
        }

        // IntFilter: digits only, with length limit (Year = 4)
        private static final class IntFilter extends DocumentFilter {
            private final int maxLen;
            IntFilter(int maxLen) { this.maxLen = maxLen; }
            private static boolean isDigits(String s) { return s.chars().allMatch(Character::isDigit); }
            @Override public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) return;
                if (!isDigits(string)) return;
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String next = new StringBuilder(cur).insert(offset, string).toString();
                if (next.length() <= maxLen) super.insertString(fb, offset, string, attr);
            }
            @Override public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String repl = text == null ? "" : text;
                if (!isDigits(repl)) return;
                String next = new StringBuilder(cur).replace(offset, offset + length, repl).toString();
                if (next.length() <= maxLen) super.replace(fb, offset, length, text, attrs);
            }
        }

        // DecimalFilter: digits + at most one dot; converts comma to dot; length limit (Mass)
        private static final class DecimalFilter extends DocumentFilter {
            private final int maxLen;
            DecimalFilter(int maxLen) { this.maxLen = maxLen; }
            private static boolean isValid(String s) {
                return s.matches("\\d*(?:\\.\\d*)?");
            }
            @Override public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) return;
                string = string.replace(',', '.');
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String next = new StringBuilder(cur).insert(offset, string).toString();
                if (next.length() <= maxLen && isValid(next) && next.chars().filter(c -> c == '.').count() <= 1) {
                    super.insertString(fb, offset, string, attr);
                }
            }
            @Override public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String cur = fb.getDocument().getText(0, fb.getDocument().getLength());
                String repl = text == null ? "" : text.replace(',', '.');
                String next = new StringBuilder(cur).replace(offset, offset + length, repl).toString();
                if (next.length() <= maxLen && isValid(next) && next.chars().filter(c -> c == '.').count() <= 1) {
                    super.replace(fb, offset, length, text == null ? null : repl, attrs);
                }
            }
        }

        /**
         * Builds the dialog (Add) and attaches input filters (soft validation).
         */
        MeteoriteForm(Window owner, String title) {
            super(owner, title, ModalityType.APPLICATION_MODAL);
            setLayout(new BorderLayout(8, 8));

            // Filters: Name max 60, Mass decimal (max 12 chars), Year digits-only (4 chars)
            setFilter(tfName, new MaxLengthFilter(60));
            setFilter(tfMass, new DecimalFilter(12));
            setFilter(tfYear, new IntFilter(4));

            var panel = new JPanel(new GridBagLayout());
            var c = new GridBagConstraints();
            c.insets = new Insets(4, 8, 4, 8);
            c.anchor = GridBagConstraints.WEST;
            c.gridy = 0;

            var lName = new JLabel("Name:");
            lName.setDisplayedMnemonic(KeyEvent.VK_N);
            lName.setLabelFor(tfName);
            tfName.setToolTipText("Meteorite name");
            tfName.getAccessibleContext().setAccessibleName("Name field");
            tfName.getAccessibleContext().setAccessibleDescription("Enter meteorite name");

            var lMass = new JLabel("Mass [g]:");
            lMass.setDisplayedMnemonic(KeyEvent.VK_M);
            lMass.setLabelFor(tfMass);
            tfMass.setToolTipText("Mass in grams");
            tfMass.getAccessibleContext().setAccessibleName("Mass field");

            var lYear = new JLabel("Year:");
            lYear.setDisplayedMnemonic(KeyEvent.VK_Y);
            lYear.setLabelFor(tfYear);
            tfYear.setToolTipText("Year of fall/discovery");
            tfYear.getAccessibleContext().setAccessibleName("Year field");

            c.gridx = 0; panel.add(lName, c);
            c.gridx = 1; panel.add(tfName, c);
            c.gridy++; c.gridx = 0; panel.add(lMass, c);
            c.gridx = 1; panel.add(tfMass, c);
            c.gridy++; c.gridx = 0; panel.add(lYear, c);
            c.gridx = 1; panel.add(tfYear, c);

            add(panel, BorderLayout.CENTER);

            var btnOk = new JButton("OK");
            btnOk.setMnemonic(KeyEvent.VK_O);
            btnOk.setToolTipText("Confirm values");
            btnOk.addActionListener(e -> {
                try {
                    String n = tfName.getText().trim();
                    double m = Double.parseDouble(tfMass.getText().trim().replace(',', '.'));
                    int  y  = Integer.parseInt(tfYear.getText().trim());

                    // Soft validation: message boxes, dialog remains open on error
                    if (n.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Name cannot be empty.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                        tfName.requestFocusInWindow();
                        return;
                    }
                    if (!Double.isFinite(m)) {
                        JOptionPane.showMessageDialog(this, "Mass must be a finite number.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                        tfMass.requestFocusInWindow();
                        return;
                    }
                    if (m <= 0) {
                        JOptionPane.showMessageDialog(this, "Mass must be positive.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                        tfMass.requestFocusInWindow();
                        return;
                    }
                    if (y < 1400 || y > 2100) {
                        JOptionPane.showMessageDialog(this, "Year must be between 1400 and 2100.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                        tfYear.requestFocusInWindow();
                        tfYear.selectAll();
                        return;
                    }

                    // OK -> set result and close the dialog
                    result = new Data(n, m, y);
                    dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Enter valid numbers for mass and year.", "Invalid input", JOptionPane.WARNING_MESSAGE);
                }
            });

            var btnCancel = new JButton("Cancel");
            btnCancel.setMnemonic(KeyEvent.VK_C);
            btnCancel.addActionListener(e -> { result = null; dispose(); });

            var buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttons.add(btnCancel);
            buttons.add(btnOk);
            add(buttons, BorderLayout.SOUTH);

            getRootPane().setDefaultButton(btnOk);
            pack();
            setLocationRelativeTo(owner);
        }

        /**
         * Prefilled constructor (Edit) – fills inputs with initial values.
         */
        MeteoriteForm(Window owner, String title, String name, double mass, int year) {
            this(owner, title);
            tfName.setText(name);
            tfMass.setText(Double.toString(mass));
            tfYear.setText(Integer.toString(year));
        }

        /** Shows the dialog (modally) and returns collected data, or {@code null} when canceled. */
        Data showDialog() { setVisible(true); return result; }
    }
}
